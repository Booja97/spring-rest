/*package com.premium.stc.dao;

import java.util.List;

import org.springframework.stereotype.Repository;

import com.premium.stc.model.IPOPlaned;
@Repository
public class IPOPlannedDaoImpl implements IPOPlanedDao {

	
	public IPOPlaned Insert(IPOPlaned ipo) {
		// TODO Auto-generated method stub
		return null;
	}

	
	public List<IPOPlaned> GetAllIPOPlaned() {
		// TODO Auto-generated method stub
		return null;
	}

}*/
