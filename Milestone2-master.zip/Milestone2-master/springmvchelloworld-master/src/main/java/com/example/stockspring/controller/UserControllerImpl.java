package com.example.stockspring.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.autoconfigure.security.SecurityProperties.User;
import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;
import org.springframework.stereotype.Controller;

import com.example.stockspring.model.user;
import com.example.stockspring.service.UserService;


@Controller
public class UserControllerImpl implements UserController {
	@Autowired
	private UserService userService;
    
	public user registerUser(user user) throws Exception {
		
		return userService.registerUser(user);
	}

	
	public user updateUser(user user) throws Exception {
	
		return userService.updateUser(user);
	}
	public static void main(String[] args) throws Exception {
		ApplicationContext applicationContext=new ClassPathXmlApplicationContext("spring.xml");
		long mobile=8608565912L;
		user user=(user)applicationContext.getBean("user");
		user.setUserId(242412);
		user.setMobileNumber(mobile);
		user.setUserName("booja");
		user.setPassword("boja");
		user.setUserType("U");
		user.setEmail("booja@gamil.com");
		user.setConfirmed(true);
		System.out.println(user);
		UserController userController=(UserController)applicationContext.getBean("userControllerImpl");
		userController.registerUser(user);
	}


	@Override
	public user updateUser(User user) throws Exception {
		// TODO Auto-generated method stub
		return null;
	}
    
	
}
