package com.example.stockspring.controller;

import org.springframework.boot.autoconfigure.security.SecurityProperties.User;

import com.example.stockspring.model.user;

public interface UserController {
	 public user registerUser(user user) throws Exception;
	 public user updateUser(User user) throws Exception;

}
