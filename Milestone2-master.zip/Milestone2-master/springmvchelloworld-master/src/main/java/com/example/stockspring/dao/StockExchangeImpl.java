package com.example.stockspring.dao;

import java.util.List;

import org.springframework.stereotype.Repository;

import com.example.stockspring.model.StockExchange;
@Repository
public class StockExchangeImpl implements StockExchangeDao {

	public StockExchange insertStock(StockExchange stockEx) {
		// TODO Auto-generated method stub
		return null;
	}

	
	public List<StockExchange> GetAllStock() {
		// TODO Auto-generated method stub
		return null;
	}

}
